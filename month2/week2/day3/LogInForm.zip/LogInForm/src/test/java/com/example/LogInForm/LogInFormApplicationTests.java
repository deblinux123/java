package com.example.LogInForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogInFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
