package com.example.LogInForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogInFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogInFormApplication.class, args);
	}

}
