package com.example.FirstPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
