package com.example.FirstPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstPageApplication.class, args);
	}

}
