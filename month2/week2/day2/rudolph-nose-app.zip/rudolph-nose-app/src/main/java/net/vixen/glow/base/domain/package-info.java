/**
 * This package contains reusable domain classes.
 */
@NullMarked
package net.vixen.glow.base.domain;

import org.jspecify.annotations.NullMarked;
