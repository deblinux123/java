@NullMarked
package net.vixen.glow.security.domain;

import org.jspecify.annotations.NullMarked;
