package com.example.WelcomePage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WelcomePageApplication {

	public static void main(String[] args) {
		SpringApplication.run(WelcomePageApplication.class, args);
	}

}
