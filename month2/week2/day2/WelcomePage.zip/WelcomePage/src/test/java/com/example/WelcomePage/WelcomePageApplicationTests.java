package com.example.WelcomePage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelcomePageApplicationTests {

	@Test
	void contextLoads() {
	}

}
