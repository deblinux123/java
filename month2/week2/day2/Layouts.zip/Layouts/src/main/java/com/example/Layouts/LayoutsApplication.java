package com.example.Layouts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LayoutsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LayoutsApplication.class, args);
	}

}
