package com.example.Layouts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LayoutsApplicationTests {

	@Test
	void contextLoads() {
	}

}
