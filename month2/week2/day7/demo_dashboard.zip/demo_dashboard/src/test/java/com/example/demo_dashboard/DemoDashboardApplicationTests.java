package com.example.demo_dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
