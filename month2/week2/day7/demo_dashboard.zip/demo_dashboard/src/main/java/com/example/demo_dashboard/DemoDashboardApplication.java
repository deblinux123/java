package com.example.demo_dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDashboardApplication.class, args);
	}

}
