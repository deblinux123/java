package com.example.TestingProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
