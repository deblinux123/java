package com.example.TableTesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TableTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TableTestingApplication.class, args);
	}

}
