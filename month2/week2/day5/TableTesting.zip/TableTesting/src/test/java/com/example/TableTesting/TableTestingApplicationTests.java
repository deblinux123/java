package com.example.TableTesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TableTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
