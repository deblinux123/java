package com.example.DashboardDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashboardDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashboardDemoApplication.class, args);
	}

}
