package com.example.DashboardDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashboardDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
