package com.example.WeatherDashboardDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherDashboardDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherDashboardDemoApplication.class, args);
	}

}
