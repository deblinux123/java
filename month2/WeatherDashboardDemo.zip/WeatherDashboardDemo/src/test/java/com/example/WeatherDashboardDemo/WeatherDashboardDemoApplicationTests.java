package com.example.WeatherDashboardDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherDashboardDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
