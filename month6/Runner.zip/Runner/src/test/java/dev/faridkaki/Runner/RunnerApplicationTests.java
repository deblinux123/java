package dev.faridkaki.Runner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
