package com.example.storeDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
